package cs2112.lecture20;

public class WeakCons_fixed {
    static class Cell { int val = 0; }
    public static void main(String[] args) {
        for (int i = 0; i < 1000; i++) {
            final Cell x = new Cell();
            final Cell y = new Cell();
            Thread t1 = new Thread() {
                public void run() {
                    synchronized (x) {
                        y.val = 1;
                        x.val = 1;
                        x.notifyAll();
                    }
                }
            };
            Thread t2 = new Thread() {
                public void run() {
                    synchronized (x) {
                        while (x.val == 0) {
                            try {
                                x.wait();
                            } catch (InterruptedException e) {
                            }
                        }
                    }
                    if (y.val != 1) System.out.println("[y!=1]");
                }
            };
            t2.start();
            t1.start();
            // try { Thread.sleep(10); } catch (Exception e) {}
            // System.out.println("Starting T1");
            try {
                t1.join();
                t2.join();
            } catch (Exception e) { System.out.println("wat");}
            System.out.print(i + " ");
        }
        System.out.println("Done");
    }
}
