package lecture17;

import javafx.application.Application;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.Separator;
import javafx.scene.control.TextArea;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class LayoutExample extends Application {
    public static void main(String[] args) {
        Application.launch(args);
    }

    int count;

    @Override
    public void start(Stage primaryStage) throws Exception {
        HBox hbox = new HBox();
        VBox vbox = new VBox();
        HBox hbox2 = new HBox();
        ScrollBar sb = new ScrollBar();
        sb.setOrientation(Orientation.VERTICAL);
        hbox.getChildren().add(vbox);
        hbox.getChildren().add(sb);
        vbox.getChildren().add(new TextArea());
        vbox.getChildren().add(hbox2);
        Button b1 = new Button("ok"), b2 = new Button("cancel");
        hbox2.getChildren().addAll(
            b1,
            new Separator(Orientation.HORIZONTAL),
            b2);

        primaryStage.setScene(new Scene(hbox));
        primaryStage.sizeToScene();
        primaryStage.show();
    }
}


