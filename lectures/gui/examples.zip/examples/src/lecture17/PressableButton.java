package lecture17;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class PressableButton extends Application {
	public static void main(String[] args) {
		Application.launch(args);
		System.out.println("main is finished :" + Thread.currentThread());	
	}

	int count;
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		System.out.println("Starting : " + Thread.currentThread());
		Button b = new Button("press me");
		b.setOnAction(e -> {
			System.out.println("Handling action: " + Thread.currentThread());
			System.out.println("pressed " + count++ + ":" +Thread.currentThread());
		});
		
		primaryStage.setScene(new Scene(b));
		primaryStage.sizeToScene();
		primaryStage.show();
	}
}

