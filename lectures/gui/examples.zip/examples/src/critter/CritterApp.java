package critter;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Polygon;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.Arrays;

// Animate a critter that walks inside a small window
public class CritterApp extends Application {
    static final int SIZE = 400;
    static double CRITTER_SCALE = 5.0, WALK_TIME = 2.0, TURN_TIME = 3.0,
            LEG_TIME = 0.5;
    Timeline timeline;
    Group critter;
    Node[] legs;

    // Critter design courtesy of Pavan Myers
    Double[] headPoints = {
            9., 7.,
            10., 7.,
            10.5, 7.5,
            11., 7.,
            12., 7.,
            12.5, 8.,
            14.5, 10.5,
            14., 15.,
            12.5, 18.,
            9.5, 18.,
            8., 15.,
            7., 10.5,
            8., 9.,
    };
    Double[] bodyPoints = {
            10., 12.5,
            12., 12.5,
            15., 14.5,
            16., 15.,
            17.5, 20.,
            18., 23.,
            15.5, 30.,
            14.3, 40.,
            14.5, 47.,
            11.2, 40.,
            9., 30.,
            7., 25.,
            6.5, 20.,
            8., 15.
    };
    Double[] leftAntennaPoints = {
            8., 8.,
            5., 6.,
            2., 3.5,
            4., 3.,
            6.5, 4.
    };
    Double[] rightAntennaPoints = {
            12., 7.,
            13., 3.,
            16., 1.,
            17., 1.,
            15., 5.,
    };
    Double[] leg1 = {
            -0.5, 1.0,
            0.5, 2.0,
            2.5, 2.5,
            3.5, 1.5,
            4.5, 3.0,
            5.5, 3.0,
            7.0, 1.5,
            6.0, 2.2,
            5.0, 2.2,
            4.2, 1.5,
            5.5, 1.5,
            6.5, 1.,
            6.5, 0.5,
            5.5, 1.,
            4.5, 1.,
            4., .5,
            5., .7,
            6., -.5,
            4.5, 0.,
            3.5, -.5,
            1.5, 1.,
            .5, -1.
    };

    static public void launch(String[] args) {
        Application.launch(args);
    }

    void bodyStyle(Node n) {
        n.setStyle("-fx-fill: #dfb; -fx-stroke: black; -fx-stroke-width: 3");
    }

    void antennaStyle(Node n) {
        n.setStyle("-fx-fill: #88a; -fx-stroke: black; -fx-stroke-width: 3");
    }

    Node eye(double x, double y, double r, double scale) {
        Group result = new Group();
        Circle c = new Circle();
        c.setCenterX(x * scale);
        c.setCenterY(y * scale);
        c.setRadius(r * scale);
        c.setStyle("-fx-fill: white; -fx-stroke: black;");

        Circle pupil = new Circle();
        pupil.setRadius(r * scale * 0.5);
        pupil.setCenterX(x * scale);
        pupil.setCenterY((y - 0 / 3) * scale);

        result.getChildren().addAll(c, pupil);
        return result;
    }

    Double[] scalePoints(Double[] pts, double offX, double offY, double scaleX, double scaleY) {
        Double[] r = new Double[pts.length];
        for (int i = 0; i < pts.length; i += 2) {
            r[i] = scaleX * (pts[i] + offX);
            r[i + 1] = scaleY * (pts[i + 1] + offY);
        }
        return r;
    }

    Node createLeg(double scaleX, double scaleY, double xOff, double yOff) {
        Polygon leg = new Polygon();
        leg.getPoints().addAll(scalePoints(leg1, 0, 0,
                scaleX * CRITTER_SCALE, scaleY * CRITTER_SCALE));
        leg.setTranslateX(xOff * CRITTER_SCALE);
        leg.setTranslateY(yOff * CRITTER_SCALE);
        bodyStyle(leg);
        return leg;
    }

    @Override
    public void start(Stage s) {
        Pane root = new Pane();
        Scene scene = new Scene(root);
        s.setScene(scene);
        root.setStyle("-fx-background-color: #aaa");

        root.setPrefWidth(SIZE);
        root.setPrefHeight(SIZE);

        critter = new Group();
        Group headSection = new Group();
        Group bodySection = new Group();
        Polygon body = new Polygon(),
                head = new Polygon(),
                leftAntenna = new Polygon(),
                rightAntenna = new Polygon();
        body.getPoints().addAll(scalePoints(bodyPoints, 0, 0, CRITTER_SCALE, CRITTER_SCALE));
        legs = new Node[6];
        legs[0] = createLeg(1.0, -1.0, 14, 14); // right leg 0
        legs[1] = createLeg(-1.0, -1.0, 8, 14); // left leg 0
        legs[2] = createLeg(1.0, -1.0, 16, 18); // right leg 1
        legs[3] = createLeg(-1.0, -1.0, 7, 18); // left leg 1
        legs[4] = createLeg(1.0, -1.0, 17.5, 23); // right leg 2
        legs[5] = createLeg(-1.0, -1.0, 7, 23); // left leg 2
        legs[0].setRotate(-10.0);
        legs[1].setRotate(10.0);
        legs[4].setRotate(10.0);
        legs[5].setRotate(-10.0);
        bodyStyle(body);
        bodyStyle(head);
        antennaStyle(leftAntenna);
        antennaStyle(rightAntenna);
        head.getPoints().addAll(scalePoints(headPoints, 0, 0, CRITTER_SCALE, CRITTER_SCALE));
        leftAntenna.getPoints().addAll(scalePoints(leftAntennaPoints, 0, 0, CRITTER_SCALE, CRITTER_SCALE));
        rightAntenna.getPoints().addAll(scalePoints(rightAntennaPoints, 0, 0, CRITTER_SCALE, CRITTER_SCALE));

        headSection.getChildren().addAll(head, leftAntenna, rightAntenna,
                eye(9.5, 12.0, 1.0, CRITTER_SCALE),
                eye(12.5, 12.0, 1.0, CRITTER_SCALE));

        bodySection.getChildren().addAll(body);
        for (Node leg : legs) {
            bodySection.getChildren().addAll(leg);
        }
        critter.getChildren().addAll(bodySection, headSection);
        root.getChildren().add(critter);

        critter.setTranslateX(SIZE / 2 - 12. * CRITTER_SCALE);
        critter.setTranslateY(SIZE / 2 - 20. * CRITTER_SCALE);

        scene.setRoot(root);
        s.show();
        setupTimeline();
    }

    void setupTimeline() {
        timeline = new Timeline(60);
        double minY =  SIZE - 47 * CRITTER_SCALE;
        for (int i = 0; i * LEG_TIME / 2 < 2 * WALK_TIME + 2 * TURN_TIME; i++) {
            for (int legIndex = 0; legIndex < 6; legIndex++) {
                Node leg = legs[legIndex];
                double t = i * LEG_TIME / 2.0 + (legIndex / 6.0) * LEG_TIME / 2.0,
                        legAng = (legIndex / 2 - 1) * 10.0 * ((legIndex % 2 == 0) ? 1 : -1),
                        angle = ((i % 2 == 0) ? 20.0 : -20.0) + legAng;
                timeline.getKeyFrames().add(new KeyFrame(Duration.seconds(t),
                        "leg" + legIndex + "_" + i, e -> {
                },
                        Arrays.asList(new KeyValue[]{
                                        new KeyValue(leg.rotateProperty(), angle)
                                }
                        )));
            }
        }
        timeline.getKeyFrames().add(new KeyFrame(Duration.seconds(WALK_TIME), "end", e -> {
        },
                Arrays.asList(new KeyValue[]{
                        new KeyValue(critter.translateYProperty(), 0.0),
                        new KeyValue(critter.rotateProperty(), 0.0)
                })));
        timeline.getKeyFrames().add(new KeyFrame(Duration.seconds(WALK_TIME + TURN_TIME), "turn", e -> {
        },
                Arrays.asList(new KeyValue[]{
                        new KeyValue(critter.translateYProperty(), 0.0),
                        new KeyValue(critter.rotateProperty(), 180.0)
                })));
        timeline.getKeyFrames().add(new KeyFrame(Duration.seconds(2 * WALK_TIME + TURN_TIME), "end2", e -> {
        },
                Arrays.asList(new KeyValue[]{
                        new KeyValue(critter.translateYProperty(), minY),
                        new KeyValue(critter.rotateProperty(), 180.0)
                })));
        timeline.getKeyFrames().add(new KeyFrame(Duration.seconds(2 * WALK_TIME + 2 * TURN_TIME), "end2",
                e -> setupTimeline(), // repeat the whole thing at the end
                Arrays.asList(new KeyValue[]{
                        new KeyValue(critter.translateYProperty(), minY),
                        new KeyValue(critter.rotateProperty(), 0.0)
                })));

        timeline.play();
    }
}
