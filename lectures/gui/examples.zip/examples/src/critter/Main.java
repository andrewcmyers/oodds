package critter;

public class Main {
    public static void main(String[] args) {
        CritterApp.launch(args);
    }
}

