package visitor;

public class BronzeCreditCard implements CreditCard{

	@Override
	public String getName() {
		return "Bronze"; 
	}


	@Override
	public double accept(OfferVisitor v, double purchasePrice) {
		return v.visit(this, purchasePrice); 
	}

}
