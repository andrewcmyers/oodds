package visitor;

public class SilverCreditCard implements CreditCard{

	@Override
	public String getName() {
		return "Silver"; 
	}

	@Override
	public double accept(OfferVisitor v, double purchasePrice) {
		return v.visit(this, purchasePrice);
	}

}
