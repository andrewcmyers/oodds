package visitor;

public interface CreditCard {
	
	String getName(); 
	double accept(OfferVisitor v, double purchasePrice); 

}
