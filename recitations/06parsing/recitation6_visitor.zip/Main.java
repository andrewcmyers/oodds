package visitor;

public class Main {
	
	public static void main(String[] args) {
		
		CreditCard card = new GoldCreditCard(); 
		OfferVisitor visitor = new GasVisitor(); 
		
		System.out.println(card.accept(visitor, 100));
//		card.accept(visitor, 100);
			
		
//		card = new SilverCreditCard(); 
//		visitor = new HotelVisitor(); 
//		
//		System.out.println(card.accept(visitor, 100)); 	
		
	}

}
 

