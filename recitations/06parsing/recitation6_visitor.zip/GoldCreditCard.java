package visitor;

public class GoldCreditCard implements CreditCard{

	@Override
	public String getName() {
		return "Gold"; 
	}


	@Override
	public double accept(OfferVisitor v, double purchasePrice) {
		return v.visit(this, purchasePrice); 
	}

}
