package visitor;

public interface OfferVisitor {
	
	double visit(BronzeCreditCard b, double purchasePrice); 
	double visit(SilverCreditCard s, double purchasePrice); 
	double visit(GoldCreditCard g, double purchasePrice);

}
