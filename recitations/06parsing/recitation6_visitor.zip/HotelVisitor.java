package visitor;

public class HotelVisitor implements OfferVisitor{

	@Override
	public double visit(BronzeCreditCard b, double purchasePrice) {
		return 0.01 * purchasePrice; 
		
	}

	@Override
	public double visit(SilverCreditCard s, double purchasePrice) {
		return 0.015 * purchasePrice; 
		
	}

	@Override
	public double visit(GoldCreditCard g, double purchasePrice) {
		return 0.05 * purchasePrice; 
		
	}
	
	

}
