package easyIO;

/** Represents the end of the input ("end of file") being reached. */
@SuppressWarnings("serial")
public class EOF extends Exception {
}
