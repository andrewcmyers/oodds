package parse;


public enum TokenType {
    LPAREN,
    RPAREN,
    NUM,
    QUOTE,
    STRING,
    ERROR,
    EOF;
}
