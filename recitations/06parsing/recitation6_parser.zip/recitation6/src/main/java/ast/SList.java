package ast;

import java.util.List;

public class SList extends AbstractNode implements Expr {
    public SList(List<Node> children) {
        super(children);
    }
}
