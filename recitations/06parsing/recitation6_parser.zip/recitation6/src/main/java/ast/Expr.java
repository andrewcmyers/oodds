package ast;

public interface Expr extends Node{
}
