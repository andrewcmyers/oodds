package ast;

public interface Atom extends Expr {

}
