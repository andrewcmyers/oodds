package ast;

import java.util.ArrayList;

public class Str extends AbstractNode implements Atom {
    private String val;

    public Str(String val) {
        super(new ArrayList<>());
        this.val = val;
    }

    
}
