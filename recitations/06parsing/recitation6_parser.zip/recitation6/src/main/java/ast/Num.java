package ast;

import java.util.ArrayList;

public class Num extends AbstractNode implements Atom {
    private int val;

    public Num(int val) {
        super(new ArrayList<>());
        this.val = val;
    }


}
