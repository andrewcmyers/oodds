package ast;

import java.util.List;

public abstract class AbstractNode implements Node{
    private final List<Node> children;

    AbstractNode(List<Node> children) {
        this.children = children;
    }

    public Node getChild(int index) {
        return children.get(index);
    }
}
