import java.util.*;

public final class UsingInstanceOf {

  public interface Expression {
  }

  public static final class AddExpression implements Expression {
    public final Expression left, right;

    public AddExpression(Expression left, Expression right) {
      this.left = left;
      this.right = right;
    }
  }

  public static final class Num implements Expression {
    public final int value;

    public Num(int value) {
      this.value = value;
    }
  }

  public static final class GlobalVariable implements Expression {
    public final String variableName;

    public GlobalVariable(String variableName) {
      this.variableName = variableName;
    }
  }

  // Problems:
  // 1. Ugly casting
  // 2. O(n) runtime, n = number of classes that implements Expression.
  // 3. If we add another Expression class, compiler will not warn us. We will
  // just fail at runtime.
  public static int evaluate(Expression expression, Map<String, Integer> globalVariables) {
    if (expression instanceof AddExpression) {
      AddExpression addExpression = (AddExpression) expression;
      int leftValue = evaluate(addExpression.left, globalVariables);
      int rightValue = evaluate(addExpression.right, globalVariables);
      return leftValue + rightValue;
    } else if (expression instanceof GlobalVariable) {
      return globalVariables.get(((GlobalVariable) expression).variableName);
    } else if (expression instanceof Num) {
      return ((Num) expression).value;
    } else {
      throw new Error("Impossible!");
    }
  }

  public static Expression constantFolding(Expression expression) {
    if (expression instanceof AddExpression) {
      AddExpression addExpression = (AddExpression) expression;
      Expression foldedLeft = constantFolding(addExpression.left);
      Expression foldedRight = constantFolding(addExpression.right);
      if (foldedLeft instanceof Num && foldedRight instanceof Num) {
        return new Num(((Num) foldedLeft).value + ((Num) foldedRight).value);
      }
      return new AddExpression(foldedLeft, foldedRight);
    } else if (expression instanceof GlobalVariable) {
      return expression;
    } else if (expression instanceof Num) {
      return expression;
    } else {
      throw new Error("Impossible!");
    }
  }
}
