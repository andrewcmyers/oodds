import java.util.*;

public final class UsingVisitor {

  public interface Expression {
    <R> R accept(ExpressionVisitor<R> visitor);
  }

  /**
   * @param <R> type of the return value.
   */
  public interface ExpressionVisitor<R> {
    R visit(AddExpression expression);

    R visit(Num expression);

    R visit(GlobalVariable expression);
  }

  public static final class AddExpression implements Expression {
    public final Expression left, right;

    public AddExpression(Expression left, Expression right) {
      this.left = left;
      this.right = right;
    }

    @Override
    public <R> R accept(ExpressionVisitor<R> visitor) {
      return visitor.visit(this);
    }
  }

  public static final class Num implements Expression {
    public final int value;

    public Num(int value) {
      this.value = value;
    }

    @Override
    public <R> R accept(ExpressionVisitor<R> visitor) {
      return visitor.visit(this);
    }
  }

  public static final class GlobalVariable implements Expression {
    public final String variableName;

    public GlobalVariable(String variableName) {
      this.variableName = variableName;
    }

    @Override
    public <R> R accept(ExpressionVisitor<R> visitor) {
      return visitor.visit(this);
    }
  }

  /**
   * Usage:
   *
   * <pre>
   * InterpretationVisitor visitor = new InterpretationVisitor();
   * Integer evaluationResult = expression.accept(visitor);
   * </pre>
   *
   * Good:
   * 1. Exhausiveness checking by compiler.
   * 2. No ugly casting.
   * 3. O(1) runtime
   * 4. No cyclic dependencies: now those AST classes are purely data holders.
   *
   * Bad: too much boilerplate.
   */
  public static final class InterpretationVisitor implements ExpressionVisitor<Integer> {

    private final Map<String, Integer> globalVariables = new HashMap<>();

    @Override
    public Integer visit(AddExpression expression) {
      return expression.left.accept(this) + expression.right.accept(this);
    }

    @Override
    public Integer visit(Num expression) {
      return expression.value;
    }

    @Override
    public Integer visit(GlobalVariable expression) {
      return globalVariables.get(expression.variableName);
    }
  }

  public static final class ConstantFoldingVisitor implements ExpressionVisitor<Expression> {

    @Override
    public Expression visit(AddExpression expression) {
      Expression foldedLeft = expression.left.accept(this);
      Expression foldedRight = expression.right.accept(this);
      if (foldedLeft instanceof Num && foldedRight instanceof Num) {
        return new Num(((Num) foldedLeft).value + ((Num) foldedRight).value);
      }
      return new AddExpression(foldedLeft, foldedRight);
    }

    @Override
    public Expression visit(Num expression) {
      return expression;
    }

    @Override
    public Expression visit(GlobalVariable expression) {
      return expression;
    }

  }
}
