import java.util.*;

public final class UsingInheritance {

  // Problem: when the program grows, there may be too many methods (even
  // unrelated) methods attached to every Expression node.
  public interface Expression {
    int evaluate(Map<String, Integer> globalVariables);

    Expression constantFolding();
  }

  public static final class AddExpression implements Expression {
    public final Expression left, right;

    public AddExpression(Expression left, Expression right) {
      this.left = left;
      this.right = right;
    }

    @Override
    public int evaluate(Map<String, Integer> globalVariables) {
      return left.evaluate(globalVariables) + right.evaluate(globalVariables);
    }

    @Override
    public Expression constantFolding() {
      Expression foldedLeft = left.constantFolding();
      Expression foldedRight = right.constantFolding();
      if (foldedLeft instanceof Num && foldedRight instanceof Num) {
        return new Num(((Num) foldedLeft).value + ((Num) foldedRight).value);
      }
      return new AddExpression(foldedLeft, foldedRight);
    }
  }

  public static final class Num implements Expression {
    public final int value;

    public Num(int value) {
      this.value = value;
    }

    @Override
    public int evaluate(Map<String, Integer> globalVariables) {
      return value;
    }

    @Override
    public Expression constantFolding() {
      return this;
    }
  }

  public static final class GlobalVariable implements Expression {
    public final String variableName;

    public GlobalVariable(String variableName) {
      this.variableName = variableName;
    }

    @Override
    public int evaluate(Map<String, Integer> globalVariables) {
      return globalVariables.get(variableName);
    }

    @Override
    public Expression constantFolding() {
      return this;
    }
  }
}
