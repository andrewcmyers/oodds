package ast;

import visitor.RegularExprVisitor;

public class EmptySet implements Node {

   @Override
   public <R> R accept(RegularExprVisitor<R> v) {
      return v.visit(this);
   }

}
