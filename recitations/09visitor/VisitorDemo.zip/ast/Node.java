package ast;

import visitor.RegularExprVisitor;

public interface Node {

   <R> R accept(RegularExprVisitor<R> v);

}
