package ast;

import visitor.RegularExprVisitor;

public class Plus implements Node {
   final public Node left;
   final public Node right;

   public Plus(Node left, Node right) {
      this.left = left;
      this.right = right;
   }

   @Override
   public <R> R accept(RegularExprVisitor<R> v) {
      return v.visit(this);
   }
}
