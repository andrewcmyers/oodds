package ast;

import visitor.RegularExprVisitor;

public class Star implements Node {
   public final Node child;

   public Star(Node child) {
      this.child = child;
   }

   @Override
   public <R> R accept(RegularExprVisitor<R> v) {
      return v.visit(this);
   }
}
