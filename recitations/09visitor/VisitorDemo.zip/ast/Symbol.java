package ast;

import visitor.RegularExprVisitor;

public class Symbol implements Node {

   public final char c;

   public Symbol(char c) {
      this.c = c;
   }

   @Override
   public <R> R accept(RegularExprVisitor<R> v) {
      return v.visit(this);
   }

}
