package visitor;

import ast.*;

public interface RegularExprVisitor<R> {

   public R visit(Symbol s);

   public R visit(Star s);

   public R visit(Plus p);

   public R visit(Concat c);

   public R visit(EmptyString e);

   public R visit(EmptySet e);

}
